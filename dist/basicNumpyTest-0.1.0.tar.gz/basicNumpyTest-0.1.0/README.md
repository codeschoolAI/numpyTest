# Basic NumPy test

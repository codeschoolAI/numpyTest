from setuptools import setup

setup(
   name='basicNumpyTest',
   version='0.1.0',
   author='Javohir Jalilov',
   author_email='javohirjaliloff@gmail.com',
   packages=['basicNumpyTest'],
   license='LICENSE.txt',
   description='This is numpy basic test',
   # required library
    install_requires=[
        "numpy",
    ]
)
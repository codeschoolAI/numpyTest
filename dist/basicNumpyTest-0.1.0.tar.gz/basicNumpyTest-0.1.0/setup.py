from setuptools import setup

setup(
   name='basicNumpyTest',
   version='0.1.0',
   packages=['basicNumpyTest'],
   description='This is numpy basic test',
   # required library
    install_requires=[
        "numpy",
    ]
)